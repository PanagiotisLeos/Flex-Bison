/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    QUOT = 258,
    STRING = 259,
    STRING_PR = 260,
    INT_NUMBER = 261,
    FLOAT = 262,
    BOOLEAN = 263,
    TEXT_LEX = 264,
    STR_NUMBER = 265,
    LAST = 266,
    ACTIVE = 267,
    GAMEID = 268,
    DRAWID = 269,
    DRAWTIME = 270,
    DRAWBREAK = 271,
    STATUS = 272,
    VISUALDRAW = 273,
    PRICEPOINTS = 274,
    AMOUNT = 275,
    WINNINGNUMBERS = 276,
    LIST = 277,
    ID = 278,
    BONUS = 279,
    PRIZECATEGORIES = 280,
    DIVIDENT = 281,
    WINNERS = 282,
    DISTRIBUTED = 283,
    JACKPOT = 284,
    FIXED = 285,
    CATEGORYTYPE = 286,
    GAMETYPE = 287,
    MINIMUMDISTRIBUTED = 288,
    WAGERSTATISTICS = 289,
    WAGERS = 290,
    COLUMNS = 291,
    ADDON = 292,
    CONTENT = 293,
    TOTALPAGES = 294,
    TOTALELEMENTS = 295,
    LAST_R = 296,
    NUMBEROFELEMENTS = 297,
    SORT = 298,
    FIRST = 299,
    SIZE = 300,
    NUMBER = 301,
    DIRECTION = 302,
    PROPERTY = 303,
    IGNORECASE = 304,
    NULLHANDLING = 305,
    DESCENDING = 306,
    ASCENDING = 307
  };
#endif
/* Tokens.  */
#define QUOT 258
#define STRING 259
#define STRING_PR 260
#define INT_NUMBER 261
#define FLOAT 262
#define BOOLEAN 263
#define TEXT_LEX 264
#define STR_NUMBER 265
#define LAST 266
#define ACTIVE 267
#define GAMEID 268
#define DRAWID 269
#define DRAWTIME 270
#define DRAWBREAK 271
#define STATUS 272
#define VISUALDRAW 273
#define PRICEPOINTS 274
#define AMOUNT 275
#define WINNINGNUMBERS 276
#define LIST 277
#define ID 278
#define BONUS 279
#define PRIZECATEGORIES 280
#define DIVIDENT 281
#define WINNERS 282
#define DISTRIBUTED 283
#define JACKPOT 284
#define FIXED 285
#define CATEGORYTYPE 286
#define GAMETYPE 287
#define MINIMUMDISTRIBUTED 288
#define WAGERSTATISTICS 289
#define WAGERS 290
#define COLUMNS 291
#define ADDON 292
#define CONTENT 293
#define TOTALPAGES 294
#define TOTALELEMENTS 295
#define LAST_R 296
#define NUMBEROFELEMENTS 297
#define SORT 298
#define FIRST 299
#define SIZE 300
#define NUMBER 301
#define DIRECTION 302
#define PROPERTY 303
#define IGNORECASE 304
#define NULLHANDLING 305
#define DESCENDING 306
#define ASCENDING 307

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
